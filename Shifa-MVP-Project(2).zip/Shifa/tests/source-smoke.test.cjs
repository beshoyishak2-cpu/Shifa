const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
test('MVP includes every requested service area', () => {
  const app = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');
  for (const feature of ['restaurant','cafe','grocery','vegetables','pharmacy','doctors','errand','prescription']) assert.ok(app.includes(feature), `missing ${feature}`);
});
test('local demo does not claim server-side orders or payments', () => {
  const app = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');
  assert.ok(app.includes('البيانات محفوظة على هذا الجهاز'));
  assert.ok(app.includes('غير مفعّل بعد'));
});
test('database schema uses row-level security and atomic order creation', () => {
  const sql = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');
  assert.ok(sql.includes('enable row level security'));
  assert.ok(sql.includes('create_customer_order'));
  assert.ok(sql.includes('transition_order'));
  assert.ok(sql.includes('protect_profile_role'));
});
