import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Geolocation } from '@capacitor/geolocation';
import { Share } from '@capacitor/share';
import { PushNotifications } from '@capacitor/push-notifications';

export const isNativeApp = () => Capacitor.isNativePlatform();
export const platform = () => Capacitor.getPlatform();

export async function takePrescriptionPhoto() {
  const photo = await Camera.getPhoto({ quality: 82, allowEditing: true, resultType: CameraResultType.DataUrl, source: CameraSource.Prompt });
  return photo.dataUrl ?? null;
}

export async function getCurrentCoordinates() {
  const position = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 12000 });
  return { latitude: position.coords.latitude, longitude: position.coords.longitude };
}

export async function shareOrder(text: string) {
  await Share.share({ title: 'طلب من شفاء', text, dialogTitle: 'مشاركة الطلب' });
}

export async function registerDevicePush(onToken: (token: string) => void) {
  if (!isNativeApp()) throw new Error('الإشعارات الفورية تتطلب تطبيق الهاتف');
  const permission = await PushNotifications.requestPermissions();
  if (permission.receive !== 'granted') throw new Error('لم يتم منح إذن الإشعارات');
  await PushNotifications.addListener('registration', (token: { value: string }) => onToken(token.value));
  await PushNotifications.addListener('registrationError', (error: unknown) => console.warn('Push registration failed', error));
  await PushNotifications.register();
}
