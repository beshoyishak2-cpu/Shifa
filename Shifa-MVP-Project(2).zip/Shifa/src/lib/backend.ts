import { supabase, backendReady } from './supabase';

export async function requestPhoneOtp(phone: string) {
  if (!supabase || !backendReady) throw new Error('لم يتم إعداد خادم شفاء بعد');
  const normalized = phone.replace(/\s+/g, '');
  const { error } = await supabase.auth.signInWithOtp({ phone: normalized, options: { shouldCreateUser: true } });
  if (error) throw error;
}

export async function verifyPhoneOtp(phone: string, token: string) {
  if (!supabase) throw new Error('لم يتم إعداد خادم شفاء بعد');
  const { data, error } = await supabase.auth.verifyOtp({ phone: phone.replace(/\s+/g, ''), token, type: 'sms' });
  if (error) throw error;
  return data.session;
}

export async function listActiveMerchants(serviceType?: string) {
  if (!supabase) return [];
  let query = supabase.from('merchants').select('id,name,service_type,description,area_name,address_text,delivery_fee,min_order,is_open').eq('verification', 'approved');
  if (serviceType) query = query.eq('service_type', serviceType);
  const { data, error } = await query.order('name');
  if (error) throw error;
  return data ?? [];
}

export async function listMerchantProducts(merchantId: string) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('products').select('id,merchant_id,name_ar,description,unit,price,old_price,stock_quantity,requires_prescription').eq('merchant_id', merchantId).eq('is_available', true).gt('stock_quantity', 0).order('name_ar');
  if (error) throw error;
  return data ?? [];
}

export async function createServerOrder(input: { merchantId: string; addressId: string; items: { product_id: string; qty: number }[]; notes?: string; customerName: string; customerPhone: string }) {
  if (!supabase) throw new Error('لم يتم إعداد خادم شفاء بعد');
  const { data, error } = await supabase.rpc('create_customer_order', {
    p_merchant_id: input.merchantId,
    p_address_id: input.addressId,
    p_items: input.items,
    p_payment_method: 'cod',
    p_notes: input.notes ?? null,
    p_customer_name: input.customerName,
    p_customer_phone: input.customerPhone
  });
  if (error) throw error;
  return data as string;
}

export function watchOrder(orderId: string, onChange: (row: Record<string, unknown>) => void) {
  if (!supabase) return () => undefined;
  const channel = supabase.channel(`shifa-order-${orderId}`).on('postgres_changes', {
    event: 'UPDATE', schema: 'public', table: 'orders', filter: `id=eq.${orderId}`
  }, (payload: any) => onChange(payload.new as Record<string, unknown>)).subscribe();
  return () => { void supabase?.removeChannel(channel); };
}
