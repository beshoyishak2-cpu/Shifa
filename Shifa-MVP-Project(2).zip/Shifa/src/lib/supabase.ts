import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

// The app remains in demo mode until real project credentials are configured.
export const supabase = url && anon ? createClient(url, anon) : null;
export const backendReady = Boolean(supabase);
