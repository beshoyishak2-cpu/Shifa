-- Shifa MVP schema for Malawy, Minya. Apply in a fresh Supabase project after review.
create extension if not exists pgcrypto;

do $$ begin create type public.app_role as enum ('customer','merchant','driver','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.partner_status as enum ('pending','approved','rejected','suspended'); exception when duplicate_object then null; end $$;
do $$ begin create type public.order_status as enum ('new','accepted','preparing','assigned','on_the_way','delivered','cancelled'); exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_method as enum ('cod','vodafone_cash','instapay'); exception when duplicate_object then null; end $$;
do $$ begin create type public.service_type as enum ('restaurant','cafe','grocery','vegetables','pharmacy'); exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', phone text unique, role public.app_role not null default 'customer',
 avatar_path text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.service_areas (
 id uuid primary key default gen_random_uuid(), name text not null unique, city text not null default 'ملوي', governorate text not null default 'المنيا',
 delivery_fee numeric(10,2) not null default 15 check(delivery_fee>=0), is_active boolean not null default true
);
create table if not exists public.addresses (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 label text not null default 'المنزل', area_id uuid references public.service_areas(id), area_name text not null default 'وسط ملوي',
 street text not null, landmark text, latitude double precision, longitude double precision, is_default boolean not null default false,
 created_at timestamptz not null default now(), check(latitude is null or latitude between -90 and 90), check(longitude is null or longitude between -180 and 180)
);
create table if not exists public.merchants (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id), name text not null,
 service_type public.service_type not null, description text, phone text not null, area_name text not null default 'ملوي', address_text text not null,
 latitude double precision, longitude double precision, logo_path text, cover_path text, opening_hours jsonb not null default '{}'::jsonb,
 min_order numeric(10,2) not null default 0 check(min_order>=0), delivery_fee numeric(10,2) not null default 15 check(delivery_fee>=0),
 commission_percent numeric(5,2) not null default 8 check(commission_percent between 0 and 30),
 verification public.partner_status not null default 'pending', is_open boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.merchant_members (
 merchant_id uuid not null references public.merchants(id) on delete cascade, user_id uuid not null references public.profiles(id) on delete cascade,
 member_role text not null default 'staff' check(member_role in ('owner','manager','staff')), created_at timestamptz not null default now(), primary key(merchant_id,user_id)
);
create table if not exists public.drivers (
 id uuid primary key default gen_random_uuid(), user_id uuid not null unique references public.profiles(id) on delete cascade,
 vehicle_type text not null default 'motorcycle', vehicle_plate text, identity_document_path text, license_document_path text,
 verification public.partner_status not null default 'pending', is_available boolean not null default false,
 service_area text not null default 'ملوي', current_lat double precision, current_lng double precision, created_at timestamptz not null default now()
);
create table if not exists public.categories (
 id uuid primary key default gen_random_uuid(), name_ar text not null, service_type public.service_type, sort_order int not null default 0, is_active boolean not null default true
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), merchant_id uuid not null references public.merchants(id) on delete cascade,
 category_id uuid references public.categories(id), name_ar text not null, description text, unit text not null default 'قطعة',
 price numeric(10,2) not null check(price>=0), old_price numeric(10,2), image_path text, stock_quantity int not null default 0 check(stock_quantity>=0),
 requires_prescription boolean not null default false, is_available boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.prescriptions (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references public.profiles(id), storage_path text not null,
 status public.partner_status not null default 'pending', assigned_merchant_id uuid references public.merchants(id), reviewed_by uuid references public.profiles(id),
 pharmacist_notes text, created_at timestamptz not null default now(), reviewed_at timestamptz
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), order_number bigint generated always as identity,
 customer_id uuid not null references public.profiles(id), merchant_id uuid references public.merchants(id), driver_id uuid references public.drivers(id),
 address_id uuid references public.addresses(id), prescription_id uuid references public.prescriptions(id),
 status public.order_status not null default 'new', subtotal numeric(10,2) not null default 0,
 delivery_fee numeric(10,2) not null default 0, discount numeric(10,2) not null default 0, total numeric(10,2) not null default 0,
 payment_method public.payment_method not null default 'cod', payment_status text not null default 'pending' check(payment_status in ('pending','paid','failed','refunded')),
 notes text, customer_name text not null, customer_phone text not null, address_snapshot jsonb not null,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid references public.products(id), product_name text not null, quantity int not null check(quantity>0),
 unit_price numeric(10,2) not null check(unit_price>=0), line_total numeric(10,2) generated always as (quantity*unit_price) stored
);
create table if not exists public.errand_requests (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references public.profiles(id), driver_id uuid references public.drivers(id),
 pickup_text text not null, dropoff_text text not null, item_description text not null, contact_phone text not null,
 notes text, quoted_fee numeric(10,2), status public.order_status not null default 'new', created_at timestamptz not null default now()
);
create table if not exists public.doctors (
 id uuid primary key default gen_random_uuid(), name text not null, specialty text not null, clinic_name text,
 address_text text not null, area_name text not null default 'ملوي', phone text, working_hours text, verified boolean not null default false, is_active boolean not null default false
);
create table if not exists public.coupons (
 id uuid primary key default gen_random_uuid(), code text unique not null, discount_percent numeric(5,2), discount_amount numeric(10,2),
 starts_at timestamptz, ends_at timestamptz, usage_limit int, used_count int not null default 0, is_active boolean not null default true
);
create table if not exists public.wallet_ledger (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id), order_id uuid references public.orders(id),
 amount numeric(10,2) not null, entry_type text not null check(entry_type in ('earning','commission','adjustment','refund')), description text, created_at timestamptz not null default now()
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 title text not null, body text not null, data jsonb not null default '{}'::jsonb, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.device_tokens (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 token text not null unique, platform text not null check(platform in ('android','ios','web')), created_at timestamptz not null default now()
);
create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(), order_id uuid not null unique references public.orders(id), customer_id uuid not null references public.profiles(id),
 merchant_rating int check(merchant_rating between 1 and 5), driver_rating int check(driver_rating between 1 and 5), comment text, created_at timestamptz not null default now()
);

create index if not exists idx_merchants_type_open on public.merchants(service_type,verification,is_open);
create index if not exists idx_products_merchant on public.products(merchant_id,is_available);
create index if not exists idx_orders_customer_created on public.orders(customer_id,created_at desc);
create index if not exists idx_orders_merchant_status on public.orders(merchant_id,status,created_at desc);
create index if not exists idx_orders_driver_status on public.orders(driver_id,status);
create index if not exists idx_notifications_user on public.notifications(user_id,created_at desc);

-- Create a profile on signup; role is always customer until approved by an administrator.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name,phone,role) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.phone,'customer') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Do not allow a user to elevate their own role through profile updates.
create or replace function public.protect_profile_role() returns trigger language plpgsql as $$
begin if auth.uid() is not null and new.role is distinct from old.role then raise exception 'role changes require administrator approval'; end if; new.updated_at=now(); return new; end; $$;
drop trigger if exists protect_profile_role_trigger on public.profiles;
create trigger protect_profile_role_trigger before update on public.profiles for each row execute procedure public.protect_profile_role();

-- Atomic server-side order creation: prices and delivery are read from database, never trusted from client.
create or replace function public.create_customer_order(
 p_merchant_id uuid, p_address_id uuid, p_items jsonb, p_payment_method public.payment_method default 'cod', p_notes text default null, p_customer_name text default null, p_customer_phone text default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_order_id uuid; v_subtotal numeric(10,2); v_delivery numeric(10,2); v_address jsonb; v_name text; v_phone text;
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'cart is empty'; end if;
 select jsonb_build_object('area',a.area_name,'street',a.street,'landmark',a.landmark,'latitude',a.latitude,'longitude',a.longitude),
        coalesce(nullif(p_customer_name,''),p.full_name),coalesce(nullif(p_customer_phone,''),p.phone)
 into v_address,v_name,v_phone from public.addresses a join public.profiles p on p.id=a.user_id where a.id=p_address_id and a.user_id=auth.uid();
 if v_address is null then raise exception 'valid customer address required'; end if;
 if coalesce(v_name,'')='' or coalesce(v_phone,'')='' then raise exception 'customer name and phone required'; end if;
 if not exists(select 1 from public.merchants where id=p_merchant_id and verification='approved' and is_open) then raise exception 'merchant is unavailable'; end if;
 select sum((pr.price)::numeric * (x.qty)::int) into v_subtotal
 from jsonb_to_recordset(p_items) as x(product_id uuid,qty int) join public.products pr on pr.id=x.product_id
 where pr.merchant_id=p_merchant_id and pr.is_available and x.qty>0 and pr.stock_quantity>=x.qty;
 if v_subtotal is null then raise exception 'invalid items or insufficient stock'; end if;
 if exists(select 1 from jsonb_to_recordset(p_items) as x(product_id uuid,qty int) left join public.products pr on pr.id=x.product_id where pr.id is null or pr.merchant_id<>p_merchant_id or not pr.is_available or x.qty<=0 or pr.stock_quantity<x.qty) then raise exception 'invalid items or insufficient stock'; end if;
 select delivery_fee into v_delivery from public.merchants where id=p_merchant_id;
 insert into public.orders(customer_id,merchant_id,status,subtotal,delivery_fee,total,payment_method,notes,customer_name,customer_phone,address_snapshot)
 values(auth.uid(),p_merchant_id,'new',v_subtotal,v_delivery,v_subtotal+v_delivery,p_payment_method,p_notes,v_name,v_phone,v_address) returning id into v_order_id;
 insert into public.order_items(order_id,product_id,product_name,quantity,unit_price)
 select v_order_id,pr.id,pr.name_ar,x.qty,pr.price from jsonb_to_recordset(p_items) as x(product_id uuid,qty int) join public.products pr on pr.id=x.product_id;
 update public.products pr set stock_quantity=pr.stock_quantity-x.qty from jsonb_to_recordset(p_items) as x(product_id uuid,qty int) where pr.id=x.product_id;
 return v_order_id;
end; $$;
revoke all on function public.create_customer_order(uuid,uuid,jsonb,public.payment_method,text,text,text) from public;
grant execute on function public.create_customer_order(uuid,uuid,jsonb,public.payment_method,text,text,text) to authenticated;

alter table public.profiles enable row level security; alter table public.addresses enable row level security; alter table public.merchants enable row level security;
alter table public.merchant_members enable row level security; alter table public.drivers enable row level security; alter table public.categories enable row level security;
alter table public.products enable row level security; alter table public.prescriptions enable row level security; alter table public.orders enable row level security;
alter table public.order_items enable row level security; alter table public.errand_requests enable row level security; alter table public.doctors enable row level security;
alter table public.coupons enable row level security; alter table public.wallet_ledger enable row level security; alter table public.notifications enable row level security;
alter table public.device_tokens enable row level security; alter table public.reviews enable row level security;

create policy "profiles read self" on public.profiles for select to authenticated using(id=auth.uid());
create policy "profiles update self safe" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "addresses owner manage" on public.addresses for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "approved merchants public" on public.merchants for select to anon,authenticated using(verification='approved');
create policy "merchant owner read" on public.merchants for select to authenticated using(owner_id=auth.uid());
create policy "merchant owner insert pending" on public.merchants for insert to authenticated with check(owner_id=auth.uid() and verification='pending');
create policy "merchant members self read" on public.merchant_members for select to authenticated using(user_id=auth.uid());
create policy "verified drivers public profile minimal" on public.drivers for select to authenticated using(verification='approved' and is_available=true);
create policy "driver self read" on public.drivers for select to authenticated using(user_id=auth.uid());
create policy "categories public" on public.categories for select to anon,authenticated using(is_active=true);
create policy "available products public" on public.products for select to anon,authenticated using(is_available=true);
create policy "prescriptions owner read" on public.prescriptions for select to authenticated using(customer_id=auth.uid());
create policy "prescriptions owner insert" on public.prescriptions for insert to authenticated with check(customer_id=auth.uid());
create policy "orders customer read" on public.orders for select to authenticated using(customer_id=auth.uid());
create policy "orders merchant read" on public.orders for select to authenticated using(exists(select 1 from public.merchant_members mm where mm.merchant_id=orders.merchant_id and mm.user_id=auth.uid()));
create policy "orders assigned driver read" on public.orders for select to authenticated using(exists(select 1 from public.drivers d where d.id=orders.driver_id and d.user_id=auth.uid()));
create policy "order items customer merchant driver read" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_items.order_id and (o.customer_id=auth.uid() or exists(select 1 from public.merchant_members mm where mm.merchant_id=o.merchant_id and mm.user_id=auth.uid()) or exists(select 1 from public.drivers d where d.id=o.driver_id and d.user_id=auth.uid()))));
create policy "errand owner read" on public.errand_requests for select to authenticated using(customer_id=auth.uid() or exists(select 1 from public.drivers d where d.id=driver_id and d.user_id=auth.uid()));
create policy "errand owner insert" on public.errand_requests for insert to authenticated with check(customer_id=auth.uid());
create policy "verified doctors public" on public.doctors for select to anon,authenticated using(is_active=true and verified=true);
create policy "active coupons public" on public.coupons for select to anon,authenticated using(is_active=true and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()));
create policy "wallet owner read" on public.wallet_ledger for select to authenticated using(user_id=auth.uid());
create policy "notifications owner read" on public.notifications for select to authenticated using(user_id=auth.uid());
create policy "notifications owner update" on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "device tokens owner manage" on public.device_tokens for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "reviews public read" on public.reviews for select to anon,authenticated using(true);
create policy "customer reviews own delivered order" on public.reviews for insert to authenticated with check(customer_id=auth.uid() and exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid() and o.status='delivered'));

-- Private storage buckets must be created in Supabase Storage: prescriptions, partner-documents, product-images.
-- Keep prescriptions and partner-documents PRIVATE. Serve files only with short-lived signed URLs after authorization.

-- Authorized order state transition. Merchant members can progress preparation; an approved driver can claim and deliver.
create or replace function public.transition_order(p_order_id uuid,p_next_status public.order_status) returns void
language plpgsql security definer set search_path=public as $$
declare v_order public.orders%rowtype; v_driver_id uuid; v_is_admin boolean; v_is_merchant boolean; v_is_driver boolean;
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 select * into v_order from public.orders where id=p_order_id for update;
 if not found then raise exception 'order not found'; end if;
 select exists(select 1 from public.profiles where id=auth.uid() and role='admin') into v_is_admin;
 select exists(select 1 from public.merchant_members where merchant_id=v_order.merchant_id and user_id=auth.uid()) into v_is_merchant;
 select id into v_driver_id from public.drivers where user_id=auth.uid() and verification='approved' and is_available limit 1;
 v_is_driver := v_driver_id is not null;
 if v_is_admin then
   update public.orders set status=p_next_status,driver_id=coalesce(driver_id,case when p_next_status='assigned' then v_driver_id end),updated_at=now() where id=p_order_id;
   return;
 end if;
 if v_is_merchant and p_next_status in ('accepted','preparing','assigned','cancelled') then
   if not ((v_order.status='new' and p_next_status in ('accepted','cancelled')) or (v_order.status='accepted' and p_next_status in ('preparing','cancelled')) or (v_order.status='preparing' and p_next_status='assigned')) then raise exception 'invalid merchant transition'; end if;
   update public.orders set status=p_next_status,updated_at=now() where id=p_order_id; return;
 end if;
 if v_is_driver and p_next_status in ('assigned','on_the_way','delivered') then
   if v_order.driver_id is null and v_order.status='assigned' and p_next_status='assigned' then
     update public.orders set driver_id=v_driver_id,updated_at=now() where id=p_order_id; return;
   end if;
   if v_order.driver_id<>v_driver_id then raise exception 'order is assigned to another driver'; end if;
   if not ((v_order.status='assigned' and p_next_status='on_the_way') or (v_order.status='on_the_way' and p_next_status='delivered')) then raise exception 'invalid driver transition'; end if;
   update public.orders set status=p_next_status,updated_at=now() where id=p_order_id; return;
 end if;
 raise exception 'not authorized to change this order';
end; $$;
revoke all on function public.transition_order(uuid,public.order_status) from public;
grant execute on function public.transition_order(uuid,public.order_status) to authenticated;

-- Errand pricing is assigned by the server (initial MVP base fare: EGP 25).
create or replace function public.create_errand_request(p_pickup_text text,p_dropoff_text text,p_item_description text,p_contact_phone text,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 if coalesce(trim(p_pickup_text),'')='' or coalesce(trim(p_dropoff_text),'')='' or coalesce(trim(p_item_description),'')='' or coalesce(trim(p_contact_phone),'')='' then raise exception 'required errand fields are missing'; end if;
 insert into public.errand_requests(customer_id,pickup_text,dropoff_text,item_description,contact_phone,notes,quoted_fee,status)
 values(auth.uid(),trim(p_pickup_text),trim(p_dropoff_text),trim(p_item_description),trim(p_contact_phone),p_notes,25,'new') returning id into v_id;
 return v_id;
end; $$;
revoke all on function public.create_errand_request(text,text,text,text,text) from public;
grant execute on function public.create_errand_request(text,text,text,text,text) to authenticated;

create or replace function public.driver_set_availability(p_available boolean) returns void
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 update public.drivers set is_available=p_available where user_id=auth.uid() and verification='approved';
 if not found then raise exception 'approved driver profile not found'; end if;
end; $$;
revoke all on function public.driver_set_availability(boolean) from public;
grant execute on function public.driver_set_availability(boolean) to authenticated;

create or replace function public.driver_update_location(p_lat double precision,p_lng double precision) returns void
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 if p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'invalid coordinates'; end if;
 update public.drivers set current_lat=p_lat,current_lng=p_lng where user_id=auth.uid() and verification='approved';
 if not found then raise exception 'approved driver profile not found'; end if;
end; $$;
revoke all on function public.driver_update_location(double precision,double precision) from public;
grant execute on function public.driver_update_location(double precision,double precision) to authenticated;

create policy "merchant members manage products" on public.products for all to authenticated
using(exists(select 1 from public.merchant_members mm where mm.merchant_id=products.merchant_id and mm.user_id=auth.uid()))
with check(exists(select 1 from public.merchant_members mm where mm.merchant_id=products.merchant_id and mm.user_id=auth.uid()));
